<?php
	echo 'll';
	sleep(2000000000);
	echo 'hello';

?>